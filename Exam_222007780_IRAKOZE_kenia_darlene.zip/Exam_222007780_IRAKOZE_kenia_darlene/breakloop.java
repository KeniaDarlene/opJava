public class breakloop {
    public static void main(String[]args){
        int m=50;
        for(m=0;m<=10;m++){
         if(m==10){
            break;
        }
            System.out.println(m);

          
        }

    }
}
