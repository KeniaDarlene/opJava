public class nestedloop {
    public static void main(String[]args){
        for(int m=0;m<=3;m++){
            System.out.println("angel" +m);
            for(int p=0;p<=3;p++){
                 System.out.println("not any" +p); 
        }
    }
}
}
