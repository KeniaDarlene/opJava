public class Forloop {
    public static void main (String[]args) throws Exception{
        int i=5;
        for(i=0;i<5;i++)
        System.out.println("Goodbye");
    }
    
}
