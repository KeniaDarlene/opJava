public class Addmeth {
    public static int addnumbers (int n1,int n2){
return n1+n2;
    }
public static void main(String[] args){
    int num1=5;
    int num2=7;
    int result = addnumbers(num1,num2);
System.out.println("sum of num1 and num2  is:" +result );
}
}
