public class doloop {
    public static void main(String[]args) {
        int i=0;
    
        do{
            i++;
            System.out.println("fine" +i);
        }
        while(i<=5);
    }
}
