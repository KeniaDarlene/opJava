public class kennyproject {
    public static void main( String[] args ) throws Exception{
        
        int i = 20;
        if (i>15)
        System.out.println("i is greater than 15");
        else
        System.out.println("i is less than 15");
        }
    }
