public class multimeth {
    public static int multnumbers(int a,int b,int c){
        return a*b*c;
    }
    public static void main(String[] args){
int x,y,z;
x=15;
y=20;
z=21;
int answ= multnumbers(x,y,z);
System.out.println("multiplication of y,x and z is:" +answ);
    }
}
